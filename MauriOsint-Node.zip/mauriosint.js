/**
 * MauriOsint - Main Entry Point
 * Launches the terminal interface and web server
 */

const MauriOsintServer = require('./src/server');

// Parse command line arguments
const args = process.argv.slice(2);
const options = {
  port: 3000,
  fetchInterval: 5 * 60 * 1000 // 5 minutes
};

// Process arguments
args.forEach(arg => {
  if (arg.startsWith('--port=')) {
    options.port = parseInt(arg.split('=')[1], 10);
  } else if (arg.startsWith('--interval=')) {
    // Convert minutes to milliseconds
    options.fetchInterval = parseInt(arg.split('=')[1], 10) * 60 * 1000;
  }
});

// Create and start server
const server = new MauriOsintServer(options);

// Handle process termination
process.on('SIGINT', () => {
  console.log('\nShutting down MauriOsint...');
  server.stop();
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('\nShutting down MauriOsint...');
  server.stop();
  process.exit(0);
});

// Start server
console.log('Starting MauriOsint...');
server.start();

console.log(`
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║   MauriOsint - أداة استخبارات مفتوحة المصدر لموريتانيا        ║
║                                                               ║
║   استخدم المفاتيح التالية للتحكم:                             ║
║   - [Q] للخروج                                                ║
║   - [S] لبدء/إيقاف جلب الأخبار                                ║
║   - [O] لفتح المتصفح                                          ║
║   - [R] لتحديث الأخبار يدوياً                                 ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
`);
