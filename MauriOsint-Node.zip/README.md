# Mauritania Injector

## Quick Start

```bash
npm start


Or directly:

node mauriosint.js


#You can also specify the port and refresh interval:


node mauriosint.js --port=3000 --interval=5

#Where:

    --port: The port the server will run on (default: 3000)

    --interval: Refresh interval in minutes (default: 5 minutes)

Terminal Interface Usage

After launching the tool, an interactive terminal interface will appear. Use the following keys to control:

    Q: Quit the program

    S: Start/Stop fetching news

    O: Open web interface in browser

    R: Manually refresh news

    Tab: Navigate between elements

Web Interface Usage

After launching the tool, you can access the web interface by opening your browser to:


http://localhost:3000

The web interface provides:

    News display in an easy-to-read format

    Filter news by source, language, date

    Search news using keywords

    Visual statistics about news sources and languages

    Real-time tracking of new news

Project Structure

mauriosint-node/
├── data/                  # Database folder
├── public/                # Web interface files
│   ├── css/               # CSS styles
│   ├── js/                # JavaScript scripts
│   └── index.html         # Main HTML page
├── src/                   # Source code
│   ├── db/                # Database module
│   ├── rss/               # RSS news fetching module
│   ├── server/            # Server module
│   └── terminal/          # Terminal interface module
├── mauriosint.js          # Main entry point
├── package.json           # Project configuration file
└── README.md              # Project documentation

