/**
 * Terminal UI Module for MauriOsint
 * Provides an interactive terminal interface with live stats
 */

const blessed = require('blessed');
const chalk = require('chalk');
const moment = require('moment');

class TerminalUI {
  constructor() {
    // Create screen
    this.screen = blessed.screen({
      smartCSR: true,
      title: 'MauriOsint - Mauritania OSINT Tool'
    });

    // Initialize UI components
    this.initUI();

    // Setup key bindings
    this.setupKeys();

    // Stats data
    this.stats = {
      totalArticles: 0,
      newArticles: 0,
      articlesBySource: {},
      articlesByLanguage: {},
      lastUpdate: null,
      serverUrl: null,
      isRunning: false
    };

    // Render initial UI
    this.screen.render();
  }

  /**
   * Initialize UI components
   */
  initUI() {
    // Create layout boxes
    this.createLayout();
    
    // Create header
    this.createHeader();
    
    // Create stats panels
    this.createStatsPanels();
    
    // Create log box
    this.createLogBox();
    
    // Create status bar
    this.createStatusBar();
  }

  /**
   * Create main layout
   */
  createLayout() {
    // Main container
    this.mainBox = blessed.box({
      top: 0,
      left: 0,
      width: '100%',
      height: '100%'
    });
    this.screen.append(this.mainBox);
  }

  /**
   * Create header
   */
  createHeader() {
    this.header = blessed.box({
      parent: this.mainBox,
      top: 0,
      left: 0,
      width: '100%',
      height: 3,
      content: chalk.green.bold(' MauriOsint ') + chalk.white('- Mauritania OSINT Tool'),
      tags: true,
      style: {
        fg: 'white',
        bg: 'blue'
      }
    });
  }

  /**
   * Create stats panels
   */
  createStatsPanels() {
    // Stats container
    this.statsContainer = blessed.box({
      parent: this.mainBox,
      top: 3,
      left: 0,
      width: '100%',
      height: 10,
      layout: 'grid'
    });

    // Total articles panel
    this.totalArticlesPanel = blessed.box({
      parent: this.statsContainer,
      top: 0,
      left: 0,
      width: '25%',
      height: 5,
      content: 'Total Articles\n0',
      tags: true,
      border: {
        type: 'line'
      },
      style: {
        border: {
          fg: 'blue'
        }
      }
    });

    // New articles panel
    this.newArticlesPanel = blessed.box({
      parent: this.statsContainer,
      top: 0,
      left: '25%',
      width: '25%',
      height: 5,
      content: 'New Articles\n0',
      tags: true,
      border: {
        type: 'line'
      },
      style: {
        border: {
          fg: 'green'
        }
      }
    });

    // Last update panel
    this.lastUpdatePanel = blessed.box({
      parent: this.statsContainer,
      top: 0,
      left: '50%',
      width: '25%',
      height: 5,
      content: 'Last Update\nNever',
      tags: true,
      border: {
        type: 'line'
      },
      style: {
        border: {
          fg: 'yellow'
        }
      }
    });

    // Status panel
    this.statusPanel = blessed.box({
      parent: this.statsContainer,
      top: 0,
      left: '75%',
      width: '25%',
      height: 5,
      content: 'Status\nStopped',
      tags: true,
      border: {
        type: 'line'
      },
      style: {
        border: {
          fg: 'red'
        }
      }
    });

    // Sources panel
    this.sourcesPanel = blessed.box({
      parent: this.statsContainer,
      top: 5,
      left: 0,
      width: '50%',
      height: 5,
      content: 'Sources',
      tags: true,
      border: {
        type: 'line'
      },
      style: {
        border: {
          fg: 'cyan'
        }
      }
    });

    // Languages panel
    this.languagesPanel = blessed.box({
      parent: this.statsContainer,
      top: 5,
      left: '50%',
      width: '50%',
      height: 5,
      content: 'Languages',
      tags: true,
      border: {
        type: 'line'
      },
      style: {
        border: {
          fg: 'magenta'
        }
      }
    });
  }

  /**
   * Create log box
   */
  createLogBox() {
    this.logBox = blessed.log({
      parent: this.mainBox,
      top: 13,
      left: 0,
      width: '100%',
      height: '100%-16',
      border: {
        type: 'line'
      },
      tags: true,
      keys: true,
      vi: true,
      mouse: true,
      scrollable: true,
      scrollbar: {
        ch: ' ',
        style: {
          bg: 'blue'
        }
      },
      style: {
        border: {
          fg: 'white'
        }
      }
    });
  }

  /**
   * Create status bar
   */
  createStatusBar() {
    this.statusBar = blessed.box({
      parent: this.mainBox,
      bottom: 0,
      left: 0,
      width: '100%',
      height: 3,
      content: ' Press [Q] to quit | [S] to start/stop | [O] to open browser | [R] to refresh',
      tags: true,
      style: {
        fg: 'white',
        bg: 'blue'
      }
    });

    // Server URL box
    this.serverUrlBox = blessed.box({
      parent: this.mainBox,
      bottom: 0,
      right: 0,
      width: '50%',
      height: 1,
      content: 'Web UI: Not started',
      tags: true,
      style: {
        fg: 'yellow',
        bg: 'blue'
      }
    });
  }

  /**
   * Setup key bindings
   */
  setupKeys() {
    // Quit on Escape, q, or Control-C
    this.screen.key(['escape', 'q', 'C-c'], () => {
      this.emit('quit');
      return process.exit(0);
    });

    // Start/Stop on S
    this.screen.key('s', () => {
      this.emit('toggleFetcher');
    });

    // Open browser on O
    this.screen.key('o', () => {
      if (this.stats.serverUrl) {
        this.emit('openBrowser', this.stats.serverUrl);
      }
    });

    // Refresh on R
    this.screen.key('r', () => {
      this.emit('manualRefresh');
    });

    // Focus on log box
    this.screen.key(['tab'], () => {
      this.logBox.focus();
    });
  }

  /**
   * Update stats display
   */
  updateStats(stats) {
    this.stats = { ...this.stats, ...stats };

    // Update total articles
    this.totalArticlesPanel.setContent(
      `Total Articles\n${chalk.bold.green(this.stats.totalArticles)}`
    );

    // Update new articles
    this.newArticlesPanel.setContent(
      `New Articles\n${chalk.bold.green(this.stats.newArticles || 0)}`
    );

    // Update last update
    const lastUpdateStr = this.stats.lastUpdate 
      ? moment(this.stats.lastUpdate).fromNow()
      : 'Never';
    this.lastUpdatePanel.setContent(
      `Last Update\n${chalk.bold.yellow(lastUpdateStr)}`
    );

    // Update status
    const statusStr = this.stats.isRunning ? 'Running' : 'Stopped';
    const statusColor = this.stats.isRunning ? chalk.bold.green : chalk.bold.red;
    this.statusPanel.setContent(
      `Status\n${statusColor(statusStr)}`
    );

    // Update sources
    let sourcesContent = 'Sources\n';
    if (this.stats.articlesBySource) {
      Object.entries(this.stats.articlesBySource).forEach(([source, count]) => {
        sourcesContent += `${source}: ${chalk.bold.cyan(count)}\n`;
      });
    }
    this.sourcesPanel.setContent(sourcesContent);

    // Update languages
    let languagesContent = 'Languages\n';
    if (this.stats.articlesByLanguage) {
      Object.entries(this.stats.articlesByLanguage).forEach(([lang, count]) => {
        const langName = lang === 'ar' ? 'Arabic' : lang === 'fr' ? 'French' : 'English';
        languagesContent += `${langName}: ${chalk.bold.magenta(count)}\n`;
      });
    }
    this.languagesPanel.setContent(languagesContent);

    // Update server URL
    if (this.stats.serverUrl) {
      this.serverUrlBox.setContent(`Web UI: ${chalk.bold.yellow(this.stats.serverUrl)}`);
    }

    // Render screen
    this.screen.render();
  }

  /**
   * Log a message
   */
  log(message, type = 'info') {
    const timestamp = moment().format('HH:mm:ss');
    let coloredMessage;

    switch (type) {
      case 'error':
        coloredMessage = chalk.red(`[${timestamp}] ${message}`);
        break;
      case 'warning':
        coloredMessage = chalk.yellow(`[${timestamp}] ${message}`);
        break;
      case 'success':
        coloredMessage = chalk.green(`[${timestamp}] ${message}`);
        break;
      case 'article':
        coloredMessage = chalk.cyan(`[${timestamp}] ${message}`);
        break;
      default:
        coloredMessage = chalk.white(`[${timestamp}] ${message}`);
    }

    this.logBox.log(coloredMessage);
    this.screen.render();
  }

  /**
   * Set server URL
   */
  setServerUrl(url) {
    this.stats.serverUrl = url;
    this.serverUrlBox.setContent(`Web UI: ${chalk.bold.yellow(url)}`);
    this.screen.render();
  }

  /**
   * Set fetcher status
   */
  setFetcherStatus(isRunning) {
    this.stats.isRunning = isRunning;
    const statusStr = isRunning ? 'Running' : 'Stopped';
    const statusColor = isRunning ? chalk.bold.green : chalk.bold.red;
    this.statusPanel.setContent(
      `Status\n${statusColor(statusStr)}`
    );
    this.screen.render();
  }

  /**
   * Event emitter methods
   */
  on(event, callback) {
    if (!this._events) this._events = {};
    if (!this._events[event]) this._events[event] = [];
    this._events[event].push(callback);
    return this;
  }

  emit(event, ...args) {
    if (!this._events || !this._events[event]) return this;
    const callbacks = this._events[event];
    callbacks.forEach(callback => callback(...args));
    return this;
  }
}

module.exports = TerminalUI;
