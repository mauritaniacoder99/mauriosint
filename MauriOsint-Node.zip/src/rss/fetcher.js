/**
 * RSS Fetcher Module for MauriOsint
 * Fetches news from Mauritanian and international sources
 */

const RSSParser = require('rss-parser');
const fetch = require('node-fetch');
const moment = require('moment');
const EventEmitter = require('events');
const crypto = require('crypto');

class RSSFetcher extends EventEmitter {
  constructor() {
    super();
    this.parser = new RSSParser({
      customFields: {
        item: [
          ['media:content', 'media'],
          ['content:encoded', 'contentEncoded']
        ]
      }
    });
    
    // RSS feeds to monitor
    this.feeds = [
      { 
        id: 'alakhbar', 
        name: 'الأخبار', 
        url: 'https://alakhbar.info/?feed=rss2', 
        language: 'ar',
        category: 'news'
      },
      { 
        id: 'essahraa', 
        name: 'الصحراء', 
        url: 'https://www.essahraa.net/feed/', 
        language: 'ar',
        category: 'news'
      },
      { 
        id: 'cridem', 
        name: 'كريدم', 
        url: 'https://cridem.org/feed/', 
        language: 'fr',
        category: 'news'
      },
      { 
        id: 'google_news', 
        name: 'Google News', 
        url: 'https://news.google.com/rss/search?q=mauritania+OR+mauritanie+OR+موريتانيا&hl=en-US&gl=US&ceid=US:en', 
        language: 'mixed',
        category: 'aggregator'
      },
      { 
        id: 'bing_news', 
        name: 'Bing News', 
        url: 'https://www.bing.com/news/search?q=mauritania+OR+mauritanie+OR+موريتانيا&format=rss', 
        language: 'mixed',
        category: 'aggregator'
      },
      // إضافة مصادر RSS جديدة
      { 
        id: 'kassataya', 
        name: 'Kassataya Mauritanie', 
        url: 'https://kassataya.com/feed', 
        language: 'fr',
        category: 'news'
      },
      { 
        id: 'lecalame', 
        name: 'Le calame', 
        url: 'https://lecalame.info/?q=rss.xml', 
        language: 'fr',
        category: 'news'
      },
      { 
        id: 'altawary', 
        name: 'Al-Tawary', 
        url: 'https://tawary.com/feed', 
        language: 'ar',
        category: 'news'
      },
      { 
        id: 'mauriweb', 
        name: 'MauriWeb', 
        url: 'https://mauriactu.info/ar/rss.xml', 
        language: 'ar',
        category: 'news'
      },
      { 
        id: 'saharamedia', 
        name: 'Sahara Media', 
        url: 'https://saharamedias.net/feed', 
        language: 'mixed',
        category: 'news'
      }
    ];
    
    this.fetchInterval = 5 * 60 * 1000; // 5 minutes
    this.fetchTimer = null;
    this.isRunning = false;
    this.stats = {
      totalArticles: 0,
      articlesBySource: {},
      articlesByLanguage: {},
      lastUpdate: null,
      newArticles: 0
    };
  }
  
  /**
   * Generate a unique ID for an article
   */
  generateArticleId(title, link) {
    const str = `${title}-${link}`;
    return crypto.createHash('md5').update(str).digest('hex');
  }
  
  /**
   * Detect language of text
   */
  detectLanguage(text) {
    // Simple language detection based on character sets and keywords
    const arabicPattern = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]/;
    const frenchKeywords = /mauritanie|afrique|président|gouvernement/i;
    
    if (arabicPattern.test(text)) {
      return 'ar';
    } else if (frenchKeywords.test(text)) {
      return 'fr';
    } else {
      return 'en';
    }
  }
  
  /**
   * Fetch a single RSS feed
   */
  async fetchFeed(feed) {
    try {
      console.log(`Fetching feed: ${feed.name} (${feed.url})`);
      
      const response = await fetch(feed.url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        },
        timeout: 10000
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const text = await response.text();
      const feedData = await this.parser.parseString(text);
      
      // Process feed items
      const articles = feedData.items.map(item => {
        // Extract content
        let content = item.contentEncoded || item.content || item.summary || '';
        
        // Extract image if available
        let imageUrl = null;
        if (item.media && item.media.$ && item.media.$.url) {
          imageUrl = item.media.$.url;
        } else if (item.enclosure && item.enclosure.url) {
          imageUrl = item.enclosure.url;
        }
        
        // Detect language if not specified by feed
        const language = feed.language === 'mixed' 
          ? this.detectLanguage(item.title + ' ' + content)
          : feed.language;
        
        // Create article object
        return {
          id: this.generateArticleId(item.title, item.link),
          title: item.title,
          content: content,
          summary: item.summary || content.substring(0, 200) + '...',
          link: item.link,
          pubDate: item.pubDate ? new Date(item.pubDate) : new Date(),
          source: {
            id: feed.id,
            name: feed.name
          },
          language: language,
          category: feed.category,
          imageUrl: imageUrl,
          createdAt: new Date()
        };
      });
      
      return articles;
    } catch (error) {
      console.error(`Error fetching feed ${feed.name}:`, error.message);
      return [];
    }
  }
  
  /**
   * Fetch all RSS feeds
   */
  async fetchAllFeeds() {
    try {
      this.emit('fetchStart');
      
      const allArticles = [];
      let newArticlesCount = 0;
      
      // Update stats
      this.stats.lastUpdate = new Date();
      
      // Fetch all feeds in parallel
      const feedPromises = this.feeds.map(feed => this.fetchFeed(feed));
      const feedResults = await Promise.all(feedPromises);
      
      // Process results
      feedResults.forEach((articles, index) => {
        const feed = this.feeds[index];
        
        // Update source stats
        if (!this.stats.articlesBySource[feed.id]) {
          this.stats.articlesBySource[feed.id] = 0;
        }
        this.stats.articlesBySource[feed.id] += articles.length;
        
        // Process articles
        articles.forEach(article => {
          // Update language stats
          if (!this.stats.articlesByLanguage[article.language]) {
            this.stats.articlesByLanguage[article.language] = 0;
          }
          this.stats.articlesByLanguage[article.language]++;
          
          // Emit new article event
          this.emit('newArticle', article);
          newArticlesCount++;
          
          // Add to all articles
          allArticles.push(article);
        });
      });
      
      // Update total stats
      this.stats.totalArticles += newArticlesCount;
      this.stats.newArticles = newArticlesCount;
      
      // Emit fetch complete event
      this.emit('fetchComplete', {
        articles: allArticles,
        stats: this.stats
      });
      
      return allArticles;
    } catch (error) {
      console.error('Error fetching all feeds:', error);
      this.emit('fetchError', error);
      return [];
    }
  }
  
  /**
   * Start continuous fetching
   */
  start() {
    if (this.isRunning) return;
    
    this.isRunning = true;
    console.log(`Starting RSS fetcher with interval: ${this.fetchInterval / 1000} seconds`);
    
    // Fetch immediately
    this.fetchAllFeeds();
    
    // Set up interval
    this.fetchTimer = setInterval(() => {
      this.fetchAllFeeds();
    }, this.fetchInterval);
    
    this.emit('started');
  }
  
  /**
   * Stop continuous fetching
   */
  stop() {
    if (!this.isRunning) return;
    
    this.isRunning = false;
    if (this.fetchTimer) {
      clearInterval(this.fetchTimer);
      this.fetchTimer = null;
    }
    
    console.log('RSS fetcher stopped');
    this.emit('stopped');
  }
  
  /**
   * Get current stats
   */
  getStats() {
    return this.stats;
  }
  
  /**
   * Set fetch interval
   */
  setFetchInterval(minutes) {
    const interval = minutes * 60 * 1000;
    this.fetchInterval = interval;
    
    // Restart if running
    if (this.isRunning) {
      this.stop();
      this.start();
    }
    
    console.log(`Fetch interval set to ${minutes} minutes`);
  }
}

module.exports = RSSFetcher;