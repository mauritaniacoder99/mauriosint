/**
 * MauriOsint Server Module
 * Integrates RSS fetcher, terminal UI, and web interface
 */

const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');
const cors = require('cors');
const { exec } = require('child_process');
const RSSFetcher = require('../rss/fetcher');
const TerminalUI = require('../terminal/ui');
const Database = require('../db/database');

class MauriOsintServer {
  constructor(options = {}) {
    // Configuration
    this.port = options.port || 3000;
    this.fetchInterval = options.fetchInterval || 5 * 60 * 1000; // 5 minutes
    
    // Initialize components
    this.db = new Database();
    this.fetcher = new RSSFetcher();
    this.terminalUI = new TerminalUI();
    
    // Set up Express app
    this.app = express();
    this.server = http.createServer(this.app);
    this.io = socketIo(this.server);
    
    // Configure Express
    this.configureExpress();
    
    // Set up socket.io
    this.configureSocketIO();
    
    // Set up event handlers
    this.setupEventHandlers();
    
    // Server URL
    this.serverUrl = null;
  }
  
  /**
   * Configure Express app
   */
  configureExpress() {
    // Enable CORS
    this.app.use(cors());
    
    // Serve static files
    this.app.use(express.static(path.join(__dirname, '../../public')));
    
    // API routes
    this.app.get('/api/news', async (req, res) => {
      try {
        const filters = {
          source: req.query.source || 'all',
          language: req.query.language || 'all',
          date: req.query.date || 'all',
          search: req.query.search || ''
        };
        
        const articles = await this.db.getArticles(filters);
        
        res.json({
          status: 'success',
          count: articles.length,
          data: articles
        });
      } catch (error) {
        console.error('Error fetching news:', error);
        res.status(500).json({
          status: 'error',
          message: error.message
        });
      }
    });
    
    this.app.get('/api/stats', async (req, res) => {
      try {
        const stats = await this.db.getStats();
        stats.fetchInterval = this.fetchInterval;
        
        res.json({
          status: 'success',
          data: stats
        });
      } catch (error) {
        console.error('Error fetching stats:', error);
        res.status(500).json({
          status: 'error',
          message: error.message
        });
      }
    });
    
    this.app.get('/api/refresh', async (req, res) => {
      try {
        this.fetcher.fetchAllFeeds();
        
        res.json({
          status: 'success',
          message: 'Refresh started'
        });
      } catch (error) {
        console.error('Error starting refresh:', error);
        res.status(500).json({
          status: 'error',
          message: error.message
        });
      }
    });
    
    // Catch-all route
    this.app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, '../../public/index.html'));
    });
  }
  
  /**
   * Configure Socket.IO
   */
  configureSocketIO() {
    this.io.on('connection', (socket) => {
      console.log('New client connected');
      this.terminalUI.log('New client connected to web UI', 'info');
      
      // Send initial data
      socket.on('getInitialData', async () => {
        try {
          const articles = await this.db.getArticles();
          const stats = await this.db.getStats();
          stats.fetchInterval = this.fetchInterval;
          stats.isRunning = this.fetcher.isRunning;
          
          socket.emit('initialData', {
            articles,
            stats
          });
        } catch (error) {
          console.error('Error sending initial data:', error);
        }
      });
      
      // Manual refresh
      socket.on('manualRefresh', () => {
        this.terminalUI.log('Manual refresh requested from web UI', 'info');
        this.fetcher.fetchAllFeeds();
      });
      
      // Disconnect
      socket.on('disconnect', () => {
        console.log('Client disconnected');
      });
    });
  }
  
  /**
   * Set up event handlers
   */
  setupEventHandlers() {
    // Terminal UI events
    this.terminalUI.on('quit', () => {
      this.stop();
      process.exit(0);
    });
    
    this.terminalUI.on('toggleFetcher', () => {
      if (this.fetcher.isRunning) {
        this.fetcher.stop();
        this.terminalUI.setFetcherStatus(false);
        this.terminalUI.log('RSS fetcher stopped', 'warning');
      } else {
        this.fetcher.start();
        this.terminalUI.setFetcherStatus(true);
        this.terminalUI.log('RSS fetcher started', 'success');
      }
    });
    
    this.terminalUI.on('openBrowser', (url) => {
      this.openBrowser(url);
    });
    
    this.terminalUI.on('manualRefresh', () => {
      this.terminalUI.log('Manual refresh requested', 'info');
      this.fetcher.fetchAllFeeds();
    });
    
    // RSS Fetcher events
    this.fetcher.on('fetchStart', () => {
      this.terminalUI.log('Starting to fetch RSS feeds...', 'info');
    });
    
    this.fetcher.on('newArticle', async (article) => {
      try {
        // Store in database
        await this.db.addArticle(article);
        
        // Log to terminal
        this.terminalUI.log(`New article: ${article.title}`, 'article');
        
        // Broadcast to clients
        this.io.emit('newArticle', article);
      } catch (error) {
        console.error('Error processing new article:', error);
      }
    });
    
    this.fetcher.on('fetchComplete', async (data) => {
      try {
        // Update stats
        const stats = await this.db.getStats();
        stats.fetchInterval = this.fetchInterval;
        stats.isRunning = this.fetcher.isRunning;
        stats.newArticles = data.stats.newArticles;
        
        // Update terminal UI
        this.terminalUI.updateStats(stats);
        this.terminalUI.log(`Fetch complete. ${data.stats.newArticles} new articles.`, 'success');
        
        // Broadcast stats to clients
        this.io.emit('statsUpdate', stats);
      } catch (error) {
        console.error('Error updating stats after fetch:', error);
      }
    });
    
    this.fetcher.on('fetchError', (error) => {
      this.terminalUI.log(`Fetch error: ${error.message}`, 'error');
    });
    
    this.fetcher.on('started', () => {
      this.terminalUI.setFetcherStatus(true);
    });
    
    this.fetcher.on('stopped', () => {
      this.terminalUI.setFetcherStatus(false);
    });
  }
  
  /**
   * Start the server
   */
  async start() {
    try {
      // Initialize database
      await this.db.initialize();
      this.terminalUI.log('Database initialized', 'success');
      
      // Start server
      this.server.listen(this.port, '0.0.0.0', () => {
        const serverUrl = `http://localhost:${this.port}`;
        this.serverUrl = serverUrl;
        
        this.terminalUI.log(`Server started on ${serverUrl}`, 'success');
        this.terminalUI.setServerUrl(serverUrl);
        
        // Get initial stats
        this.db.getStats().then(stats => {
          stats.fetchInterval = this.fetchInterval;
          this.terminalUI.updateStats(stats);
        });
        
        // Start RSS fetcher
        this.fetcher.setFetchInterval(this.fetchInterval / (60 * 1000)); // Convert to minutes
        this.fetcher.start();
      });
    } catch (error) {
      console.error('Error starting server:', error);
      this.terminalUI.log(`Error starting server: ${error.message}`, 'error');
    }
  }
  
  /**
   * Stop the server
   */
  stop() {
    // Stop RSS fetcher
    if (this.fetcher.isRunning) {
      this.fetcher.stop();
    }
    
    // Close server
    if (this.server) {
      this.server.close();
      this.terminalUI.log('Server stopped', 'warning');
    }
  }
  
  /**
   * Open browser
   */
  openBrowser(url) {
    let command;
    
    switch (process.platform) {
      case 'darwin': // macOS
        command = `open "${url}"`;
        break;
      case 'win32': // Windows
        command = `start "" "${url}"`;
        break;
      default: // Linux and others
        command = `xdg-open "${url}"`;
    }
    
    exec(command, (error) => {
      if (error) {
        this.terminalUI.log(`Error opening browser: ${error.message}`, 'error');
      } else {
        this.terminalUI.log(`Browser opened to ${url}`, 'success');
      }
    });
  }
}

module.exports = MauriOsintServer;
