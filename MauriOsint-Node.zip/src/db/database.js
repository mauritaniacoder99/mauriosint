/**
 * Database Module for MauriOsint
 * Handles storage and retrieval of news articles
 */

const Datastore = require('nedb');
const path = require('path');
const fs = require('fs');

class Database {
  constructor(options = {}) {
    // Set data directory
    this.dataDir = options.dataDir || path.join(__dirname, '../../data');
    
    // Ensure data directory exists
    if (!fs.existsSync(this.dataDir)) {
      fs.mkdirSync(this.dataDir, { recursive: true });
    }
    
    // Initialize database files
    this.articlesDb = new Datastore({
      filename: path.join(this.dataDir, 'articles.db'),
      autoload: true
    });
    
    this.statsDb = new Datastore({
      filename: path.join(this.dataDir, 'stats.db'),
      autoload: true
    });
    
    // Configure databases
    this.articlesDb.ensureIndex({ fieldName: 'id', unique: true });
  }
  
  /**
   * Initialize database
   */
  async initialize() {
    return new Promise((resolve, reject) => {
      // Compact databases
      this.articlesDb.persistence.compactDatafile();
      this.statsDb.persistence.compactDatafile();
      
      // Initialize stats if needed
      this.statsDb.findOne({}, (err, stats) => {
        if (err) return reject(err);
        
        if (!stats) {
          const initialStats = {
            totalArticles: 0,
            articlesBySource: {},
            articlesByLanguage: {},
            lastUpdate: new Date()
          };
          
          this.statsDb.insert(initialStats, (err) => {
            if (err) return reject(err);
            resolve();
          });
        } else {
          resolve();
        }
      });
    });
  }
  
  /**
   * Add article to database
   */
  async addArticle(article) {
    return new Promise((resolve, reject) => {
      // Check if article already exists
      this.articlesDb.findOne({ id: article.id }, (err, existingArticle) => {
        if (err) return reject(err);
        
        if (existingArticle) {
          // Update existing article
          this.articlesDb.update(
            { id: article.id },
            { $set: { ...article, updatedAt: new Date() } },
            {},
            (err) => {
              if (err) return reject(err);
              resolve(article);
            }
          );
        } else {
          // Add new article
          const newArticle = {
            ...article,
            createdAt: new Date(),
            updatedAt: new Date()
          };
          
          this.articlesDb.insert(newArticle, (err) => {
            if (err) return reject(err);
            
            // Update stats
            this.updateStats(article);
            
            resolve(newArticle);
          });
        }
      });
    });
  }
  
  /**
   * Get articles with optional filters
   */
  async getArticles(filters = {}) {
    return new Promise((resolve, reject) => {
      let query = {};
      
      // Apply filters
      if (filters.source && filters.source !== 'all') {
        query['source.id'] = filters.source;
      }
      
      if (filters.language && filters.language !== 'all') {
        query.language = filters.language;
      }
      
      if (filters.date && filters.date !== 'all') {
        const now = new Date();
        let dateLimit;
        
        switch (filters.date) {
          case 'today':
            dateLimit = new Date(now.setHours(0, 0, 0, 0));
            break;
          case 'yesterday':
            dateLimit = new Date(now.setDate(now.getDate() - 1));
            dateLimit.setHours(0, 0, 0, 0);
            break;
          case 'week':
            dateLimit = new Date(now.setDate(now.getDate() - 7));
            break;
          case 'month':
            dateLimit = new Date(now.setMonth(now.getMonth() - 1));
            break;
        }
        
        query.pubDate = { $gte: dateLimit };
      }
      
      if (filters.search && filters.search.trim() !== '') {
        const searchRegex = new RegExp(filters.search, 'i');
        query.$or = [
          { title: searchRegex },
          { content: searchRegex },
          { summary: searchRegex }
        ];
      }
      
      // Execute query
      this.articlesDb
        .find(query)
        .sort({ pubDate: -1 })
        .exec((err, articles) => {
          if (err) return reject(err);
          resolve(articles);
        });
    });
  }
  
  /**
   * Get database statistics
   */
  async getStats() {
    return new Promise((resolve, reject) => {
      this.statsDb.findOne({}, (err, stats) => {
        if (err) return reject(err);
        
        if (!stats) {
          const initialStats = {
            totalArticles: 0,
            articlesBySource: {},
            articlesByLanguage: {},
            lastUpdate: new Date()
          };
          
          resolve(initialStats);
        } else {
          resolve(stats);
        }
      });
    });
  }
  
  /**
   * Update statistics
   */
  async updateStats(article) {
    return new Promise((resolve, reject) => {
      this.statsDb.findOne({}, (err, stats) => {
        if (err) return reject(err);
        
        if (!stats) {
          stats = {
            totalArticles: 0,
            articlesBySource: {},
            articlesByLanguage: {},
            lastUpdate: new Date()
          };
        }
        
        // Update total articles
        stats.totalArticles = (stats.totalArticles || 0) + 1;
        
        // Update articles by source
        const sourceId = article.source.id;
        stats.articlesBySource[sourceId] = (stats.articlesBySource[sourceId] || 0) + 1;
        
        // Update articles by language
        const language = article.language;
        stats.articlesByLanguage[language] = (stats.articlesByLanguage[language] || 0) + 1;
        
        // Update last update time
        stats.lastUpdate = new Date();
        
        // Save stats
        this.statsDb.update({}, stats, { upsert: true }, (err) => {
          if (err) return reject(err);
          resolve(stats);
        });
      });
    });
  }
  
  /**
   * Clear database
   */
  async clear() {
    return new Promise((resolve, reject) => {
      // Remove all articles
      this.articlesDb.remove({}, { multi: true }, (err) => {
        if (err) return reject(err);
        
        // Reset stats
        const initialStats = {
          totalArticles: 0,
          articlesBySource: {},
          articlesByLanguage: {},
          lastUpdate: new Date()
        };
        
        this.statsDb.update({}, initialStats, { upsert: true }, (err) => {
          if (err) return reject(err);
          
          // Compact databases
          this.articlesDb.persistence.compactDatafile();
          this.statsDb.persistence.compactDatafile();
          
          resolve();
        });
      });
    });
  }
}

module.exports = Database;
