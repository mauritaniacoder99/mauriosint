/**
 * MauriOsint Frontend JavaScript
 * Handles real-time updates and UI interactions
 */

// Initialize socket connection
let socket;
let isConnected = false;
let articles = [];
let currentFilters = {
    source: 'all',
    language: 'all',
    date: 'all',
    search: ''
};

// Charts
let sourcesChart;
let languagesChart;

// Connect to the server
function connectSocket() {
    // Get the host from the current URL
    const host = window.location.host;
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    
    // Connect to socket.io server
    socket = io();
    
    // Connection events
    socket.on('connect', () => {
        console.log('Connected to server');
        isConnected = true;
        updateConnectionStatus(true);
        
        // Request initial data
        socket.emit('getInitialData');
    });
    
    socket.on('disconnect', () => {
        console.log('Disconnected from server');
        isConnected = false;
        updateConnectionStatus(false);
    });
    
    // Data events
    socket.on('initialData', (data) => {
        console.log('Received initial data', data);
        
        // Update stats
        updateStats(data.stats);
        
        // Update articles
        articles = data.articles || [];
        renderArticles();
        
        // Update source filter options
        updateSourceFilterOptions(data.stats.articlesBySource);
        
        // Update charts
        updateCharts(data.stats);
    });
    
    socket.on('newArticle', (article) => {
        console.log('New article received', article);
        
        // Add to articles array
        articles.unshift(article);
        
        // Update UI
        updateNewArticleCount(1);
        addToLiveFeed(article);
        
        // Re-render if it matches current filters
        if (matchesFilters(article, currentFilters)) {
            renderArticles();
        }
    });
    
    socket.on('statsUpdate', (stats) => {
        console.log('Stats update received', stats);
        updateStats(stats);
        updateCharts(stats);
    });
}

// Update connection status in UI
function updateConnectionStatus(connected) {
    const statusElement = document.getElementById('serverStatus');
    const connectionElement = document.getElementById('connectionStatus');
    
    if (connected) {
        statusElement.textContent = 'متصل';
        statusElement.className = 'display-6 text-success';
        connectionElement.innerHTML = '<i class="bi bi-wifi"></i> <span>متصل</span>';
        connectionElement.className = 'mb-0 text-success';
    } else {
        statusElement.textContent = 'غير متصل';
        statusElement.className = 'display-6 text-danger';
        connectionElement.innerHTML = '<i class="bi bi-wifi-off"></i> <span>غير متصل</span>';
        connectionElement.className = 'mb-0 text-danger';
    }
}

// Update stats in UI
function updateStats(stats) {
    // Total articles
    const totalArticlesElement = document.getElementById('totalArticles');
    totalArticlesElement.textContent = stats.totalArticles || 0;
    
    // New articles
    const newArticlesElement = document.getElementById('newArticles');
    newArticlesElement.textContent = stats.newArticles || 0;
    
    // Last update
    const lastUpdateElement = document.getElementById('lastUpdate');
    if (stats.lastUpdate) {
        moment.locale('ar');
        lastUpdateElement.textContent = moment(stats.lastUpdate).fromNow();
    } else {
        lastUpdateElement.textContent = '-';
    }
    
    // Next update
    const nextUpdateElement = document.getElementById('nextUpdate');
    if (stats.lastUpdate && stats.fetchInterval) {
        const nextUpdate = moment(stats.lastUpdate).add(stats.fetchInterval, 'milliseconds');
        nextUpdateElement.innerHTML = 'التحديث التالي: <span>' + moment(nextUpdate).fromNow() + '</span>';
    } else {
        nextUpdateElement.innerHTML = 'التحديث التالي: <span>-</span>';
    }
    
    // Articles count
    const articlesCountElement = document.getElementById('articlesCount');
    articlesCountElement.textContent = articles.length;
}

// Update new article count
function updateNewArticleCount(count) {
    const newArticlesElement = document.getElementById('newArticles');
    const currentCount = parseInt(newArticlesElement.textContent) || 0;
    newArticlesElement.textContent = currentCount + count;
}

// Add article to live feed
function addToLiveFeed(article) {
    const liveFeedElement = document.getElementById('liveFeed');
    
    // Create new item
    const item = document.createElement('div');
    item.className = 'list-group-item';
    
    // Format time
    moment.locale('ar');
    const time = moment(article.pubDate).fromNow();
    
    // Determine language icon
    let langIcon = '';
    switch (article.language) {
        case 'ar':
            langIcon = '<i class="bi bi-translate text-success"></i>';
            break;
        case 'fr':
            langIcon = '<i class="bi bi-translate text-primary"></i>';
            break;
        case 'en':
            langIcon = '<i class="bi bi-translate text-info"></i>';
            break;
    }
    
    // Set content
    item.innerHTML = `
        <div class="d-flex justify-content-between align-items-center">
            <small class="text-truncate">${article.title}</small>
            <span class="badge bg-secondary ms-2">${langIcon}</span>
        </div>
        <div class="d-flex justify-content-between align-items-center">
            <small class="text-muted">${article.source.name}</small>
            <small class="text-muted">${time}</small>
        </div>
    `;
    
    // Add to feed
    liveFeedElement.prepend(item);
    
    // Limit items
    const items = liveFeedElement.querySelectorAll('.list-group-item');
    if (items.length > 10) {
        liveFeedElement.removeChild(items[items.length - 1]);
    }
}

// Update source filter options
function updateSourceFilterOptions(sourceStats) {
    const sourceFilterElement = document.getElementById('sourceFilter');
    
    // Clear existing options except "All"
    while (sourceFilterElement.options.length > 1) {
        sourceFilterElement.remove(1);
    }
    
    // Add options for each source
    if (sourceStats) {
        Object.entries(sourceStats).forEach(([sourceId, count]) => {
            const option = document.createElement('option');
            option.value = sourceId;
            option.textContent = `${getSourceName(sourceId)} (${count})`;
            sourceFilterElement.appendChild(option);
        });
    }
}

// Get source name from ID
function getSourceName(sourceId) {
    const sourceNames = {
        'alakhbar': 'الأخبار',
        'essahraa': 'الصحراء',
        'cridem': 'كريدم',
        'google_news': 'Google News',
        'bing_news': 'Bing News'
    };
    
    return sourceNames[sourceId] || sourceId;
}

// Update charts
function updateCharts(stats) {
    // Sources chart
    updateSourcesChart(stats.articlesBySource);
    
    // Languages chart
    updateLanguagesChart(stats.articlesByLanguage);
}

// Update sources chart
function updateSourcesChart(sourceStats) {
    const ctx = document.getElementById('sourcesChart').getContext('2d');
    
    // Prepare data
    const labels = [];
    const data = [];
    const backgroundColors = [
        'rgba(255, 99, 132, 0.7)',
        'rgba(54, 162, 235, 0.7)',
        'rgba(255, 206, 86, 0.7)',
        'rgba(75, 192, 192, 0.7)',
        'rgba(153, 102, 255, 0.7)'
    ];
    
    if (sourceStats) {
        Object.entries(sourceStats).forEach(([sourceId, count], index) => {
            labels.push(getSourceName(sourceId));
            data.push(count);
        });
    }
    
    // Create or update chart
    if (sourcesChart) {
        sourcesChart.data.labels = labels;
        sourcesChart.data.datasets[0].data = data;
        sourcesChart.update();
    } else {
        sourcesChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: backgroundColors,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'right',
                    }
                }
            }
        });
    }
}

// Update languages chart
function updateLanguagesChart(languageStats) {
    const ctx = document.getElementById('languagesChart').getContext('2d');
    
    // Prepare data
    const labels = [];
    const data = [];
    const backgroundColors = [
        'rgba(75, 192, 192, 0.7)',
        'rgba(54, 162, 235, 0.7)',
        'rgba(255, 99, 132, 0.7)'
    ];
    
    const languageNames = {
        'ar': 'العربية',
        'fr': 'الفرنسية',
        'en': 'الإنجليزية'
    };
    
    if (languageStats) {
        Object.entries(languageStats).forEach(([langCode, count], index) => {
            labels.push(languageNames[langCode] || langCode);
            data.push(count);
        });
    }
    
    // Create or update chart
    if (languagesChart) {
        languagesChart.data.labels = labels;
        languagesChart.data.datasets[0].data = data;
        languagesChart.update();
    } else {
        languagesChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'عدد الأخبار',
                    data: data,
                    backgroundColor: backgroundColors,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
}

// Render articles based on current filters
function renderArticles() {
    const newsContainer = document.getElementById('newsContainer');
    
    // Clear container
    newsContainer.innerHTML = '';
    
    // Filter articles
    const filteredArticles = articles.filter(article => matchesFilters(article, currentFilters));
    
    // Update count
    const articlesCountElement = document.getElementById('articlesCount');
    articlesCountElement.textContent = filteredArticles.length;
    
    // Check if no articles
    if (filteredArticles.length === 0) {
        newsContainer.innerHTML = `
            <div class="text-center p-5">
                <i class="bi bi-inbox display-1 text-muted"></i>
                <p class="mt-2">لا توجد أخبار تطابق معايير البحث</p>
            </div>
        `;
        return;
    }
    
    // Render articles
    filteredArticles.forEach(article => {
        // Create article element
        const articleElement = document.createElement('div');
        articleElement.className = 'list-group-item';
        
        // Format date
        moment.locale('ar');
        const date = moment(article.pubDate).fromNow();
        
        // Determine language badge
        let langBadge = '';
        switch (article.language) {
            case 'ar':
                langBadge = '<span class="badge bg-success">العربية</span>';
                break;
            case 'fr':
                langBadge = '<span class="badge bg-primary">الفرنسية</span>';
                break;
            case 'en':
                langBadge = '<span class="badge bg-info">الإنجليزية</span>';
                break;
        }
        
        // Set content
        articleElement.innerHTML = `
            <div class="d-flex w-100 justify-content-between">
                <h5 class="mb-1">${article.title}</h5>
                <small>${date}</small>
            </div>
            <p class="mb-1">${article.summary}</p>
            <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">${article.source.name}</small>
                <div>
                    ${langBadge}
                    <button class="btn btn-sm btn-outline-primary view-article" data-id="${article.id}">
                        قراءة المزيد
                    </button>
                </div>
            </div>
        `;
        
        // Add to container
        newsContainer.appendChild(articleElement);
        
        // Add click event for view button
        const viewButton = articleElement.querySelector('.view-article');
        viewButton.addEventListener('click', () => {
            showArticleModal(article);
        });
    });
}

// Check if article matches filters
function matchesFilters(article, filters) {
    // Source filter
    if (filters.source !== 'all' && article.source.id !== filters.source) {
        return false;
    }
    
    // Language filter
    if (filters.language !== 'all' && article.language !== filters.language) {
        return false;
    }
    
    // Date filter
    if (filters.date !== 'all') {
        const pubDate = moment(article.pubDate);
        const now = moment();
        
        switch (filters.date) {
            case 'today':
                if (!pubDate.isSame(now, 'day')) {
                    return false;
                }
                break;
            case 'yesterday':
                if (!pubDate.isSame(now.subtract(1, 'days'), 'day')) {
                    return false;
                }
                break;
            case 'week':
                if (!pubDate.isAfter(now.subtract(7, 'days'))) {
                    return false;
                }
                break;
            case 'month':
                if (!pubDate.isAfter(now.subtract(30, 'days'))) {
                    return false;
                }
                break;
        }
    }
    
    // Search filter
    if (filters.search && filters.search.trim() !== '') {
        const searchTerm = filters.search.toLowerCase();
        const title = article.title.toLowerCase();
        const content = article.content ? article.content.toLowerCase() : '';
        const summary = article.summary ? article.summary.toLowerCase() : '';
        
        if (!title.includes(searchTerm) && !content.includes(searchTerm) && !summary.includes(searchTerm)) {
            return false;
        }
    }
    
    return true;
}

// Show article modal
function showArticleModal(article) {
    const modalTitle = document.getElementById('articleModalLabel');
    const modalContent = document.getElementById('articleContent');
    const modalLink = document.getElementById('articleLink');
    
    // Set title
    modalTitle.textContent = article.title;
    
    // Set content
    modalContent.innerHTML = `
        <div class="mb-3">
            <small class="text-muted">
                ${article.source.name} | 
                ${moment(article.pubDate).format('LLLL')}
            </small>
        </div>
        <div class="article-content">
            ${article.content || article.summary}
        </div>
    `;
    
    // Set link
    modalLink.href = article.link;
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('articleModal'));
    modal.show();
}

// Setup event listeners
function setupEventListeners() {
    // Refresh button
    const refreshBtn = document.getElementById('refreshBtn');
    refreshBtn.addEventListener('click', () => {
        if (isConnected) {
            socket.emit('manualRefresh');
            refreshBtn.disabled = true;
            refreshBtn.innerHTML = '<i class="bi bi-arrow-repeat"></i> جاري التحديث...';
            
            // Re-enable after 5 seconds
            setTimeout(() => {
                refreshBtn.disabled = false;
                refreshBtn.innerHTML = '<i class="bi bi-arrow-clockwise"></i> تحديث الأخبار';
            }, 5000);
        }
    });
    
    // Language dropdown
    const languageLinks = document.querySelectorAll('[data-lang]');
    languageLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const lang = link.getAttribute('data-lang');
            document.documentElement.lang = lang;
            document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
        });
    });
    
    // Source filter
    const sourceFilter = document.getElementById('sourceFilter');
    sourceFilter.addEventListener('change', () => {
        currentFilters.source = sourceFilter.value;
        renderArticles();
    });
    
    // Language filter
    const languageFilter = document.getElementById('languageFilter');
    languageFilter.addEventListener('change', () => {
        currentFilters.language = languageFilter.value;
        renderArticles();
    });
    
    // Date filter
    const dateFilter = document.getElementById('dateFilter');
    dateFilter.addEventListener('change', () => {
        currentFilters.date = dateFilter.value;
        renderArticles();
    });
    
    // Search filter
    const searchBtn = document.getElementById('searchBtn');
    const searchFilter = document.getElementById('searchFilter');
    
    searchBtn.addEventListener('click', () => {
        currentFilters.search = searchFilter.value;
        renderArticles();
    });
    
    searchFilter.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            currentFilters.search = searchFilter.value;
            renderArticles();
        }
    });
}

// Initialize app
function initApp() {
    // Set up moment locale
    moment.locale('ar');
    
    // Connect to socket
    connectSocket();
    
    // Setup event listeners
    setupEventListeners();
    
    // Update time displays periodically
    setInterval(() => {
        // Update last update time
        const lastUpdateElement = document.getElementById('lastUpdate');
        if (lastUpdateElement.textContent !== '-') {
            lastUpdateElement.textContent = moment(lastUpdateElement.getAttribute('data-time')).fromNow();
        }
        
        // Update next update time
        const nextUpdateElement = document.getElementById('nextUpdate');
        const nextUpdateTime = nextUpdateElement.querySelector('span');
        if (nextUpdateTime && nextUpdateTime.getAttribute('data-time')) {
            nextUpdateTime.textContent = moment(nextUpdateTime.getAttribute('data-time')).fromNow();
        }
    }, 30000); // Update every 30 seconds
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', initApp);
